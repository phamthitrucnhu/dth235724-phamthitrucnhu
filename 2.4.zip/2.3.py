toan=float(input("Nhập điểm Toán:"))
ly=float(input("Nhập điểm lý:"))
hoa=float(input("Nhập điểm hóa:"))
dtb=(toan+ly+hoa)/3
print("Điểm trung bình=",dtb)
print("Điểm trung bình=",round(dtb,2))