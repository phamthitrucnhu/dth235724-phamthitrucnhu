#         |1. Kiểu số học (Numeric Types) :int float complex
#2. Kiểu chuỗi (Text Type): str
#3. Kiểu logic: bool(đ/s)
#4. Kiểu tập hợp (Collection Types):dict set tuple ..
# 5. Kiểu nhị phân (Binary Types): memoryview bytearray bytes