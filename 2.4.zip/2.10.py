#a x = x + 1
#→ Viết ngắn gọn: x += 1

#(b) x = x / 2
#→ Viết ngắn gọn: x /= 2

#(c) x = x - 1
#→ Viết ngắn gọn: x -= 1

#(d) x = x + y
#→ Viết ngắn gọn: x += y

#(e) x = x - (y + 7)
#→ Viết ngắn gọn: x -= (y + 7)

#(f) x = 2 * x
#→ Viết ngắn gọn: x *= 2

#(g) number_of_closed_cases = number_of_closed_cases + 2 * ncc
#→ Viết ngắn gọn: number_of_closed_cases += 2 * ncc